export const calculateCBM = (length, width, height, quantity) => {
  const cbmPerItem = (length / 100) * (width / 100) * (height / 100);
  return cbmPerItem * quantity;
};
