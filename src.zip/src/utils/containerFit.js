export const suggestContainer = (totalCBM) => {
  if (totalCBM <= 28) return '20ft Container';
  if (totalCBM <= 58) return '40ft Container';
  if (totalCBM <= 68) return '40HC Container';
  return 'Multiple Containers Needed';
};
