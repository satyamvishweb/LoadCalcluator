import React, { useState, useRef, useEffect } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';
import { Package, Calculator, Eye, Download, Plus, Trash2, Container, Info } from 'lucide-react';

const SeaFreightCalculator = () => {
  const [items, setItems] = useState([]);
  const [currentItem, setCurrentItem] = useState({
    name: '',
    length: '',
    width: '',
    height: '',
    weight: '',
    quantity: 1,
    stackable: true,
    fragile: false
  });
  const [results, setResults] = useState(null);
  const [activeTab, setActiveTab] = useState('input');
  const [selectedContainer, setSelectedContainer] = useState('20ft');
  const mountRef = useRef(null);
  const sceneRef = useRef(null);
  const rendererRef = useRef(null);
  const cameraRef = useRef(null);
  const controlsRef = useRef(null);

  // Container specifications
  const containerSpecs = {
    '20ft': {
      name: '20ft Standard',
      length: 5.898,
      width: 2.352,
      height: 2.393,
      maxWeight: 28200,
      volume: 33.2
    },
    '40ft': {
      name: '40ft Standard',
      length: 12.032,
      width: 2.352,
      height: 2.393,
      maxWeight: 26700,
      volume: 67.7
    },
    '40hc': {
      name: '40ft High Cube',
      length: 12.032,
      width: 2.352,
      height: 2.698,
      maxWeight: 26700,
      volume: 76.3
    }
  };

  // 3D Bin Packing Algorithm
  const binPackingAlgorithm = (items, container) => {
    const containerDim = containerSpecs[container];
    let placedItems = [];
    let totalWeight = 0;
    let totalVolume = 0;
    let occupiedSpaces = [];

    // Expand items based on quantity
    const expandedItems = [];
    items.forEach(item => {
      for (let i = 0; i < item.quantity; i++) {
        expandedItems.push({
          ...item,
          id: `${item.name}_${i}`,
          volume: (item.length * item.width * item.height) / 1000000 // Convert to cubic meters
        });
      }
    });

    // Sort items by volume (largest first)
    expandedItems.sort((a, b) => b.volume - a.volume);

    expandedItems.forEach(item => {
      const itemDim = {
        length: item.length / 100, // Convert cm to meters
        width: item.width / 100,
        height: item.height / 100
      };

      // Check if item fits in container
      if (itemDim.length <= containerDim.length && 
          itemDim.width <= containerDim.width && 
          itemDim.height <= containerDim.height &&
          totalWeight + item.weight <= containerDim.maxWeight) {
        
        // Find best position
        let bestPosition = findBestPosition(itemDim, occupiedSpaces, containerDim);
        
        if (bestPosition) {
          placedItems.push({
            ...item,
            position: bestPosition,
            dimensions: itemDim
          });
          
          occupiedSpaces.push({
            x: bestPosition.x,
            y: bestPosition.y,
            z: bestPosition.z,
            length: itemDim.length,
            width: itemDim.width,
            height: itemDim.height
          });
          
          totalWeight += item.weight;
          totalVolume += item.volume;
        }
      }
    });

    return {
      placedItems,
      totalWeight,
      totalVolume,
      utilization: (totalVolume / containerDim.volume) * 100,
      weightUtilization: (totalWeight / containerDim.maxWeight) * 100
    };
  };

  const findBestPosition = (itemDim, occupiedSpaces, containerDim) => {
    // Try to place item at origin first
    let positions = [{ x: 0, y: 0, z: 0 }];
    
    // Generate positions based on existing items
    occupiedSpaces.forEach(space => {
      positions.push(
        { x: space.x + space.length, y: space.y, z: space.z },
        { x: space.x, y: space.y + space.width, z: space.z },
        { x: space.x, y: space.y, z: space.z + space.height }
      );
    });

    // Sort positions by lowest point first (bottom-left-front)
    positions.sort((a, b) => a.z - b.z || a.y - b.y || a.x - b.x);

    for (let pos of positions) {
      if (canPlaceItem(pos, itemDim, occupiedSpaces, containerDim)) {
        return pos;
      }
    }
    
    return null;
  };

  const canPlaceItem = (position, itemDim, occupiedSpaces, containerDim) => {
    // Check container bounds
    if (position.x + itemDim.length > containerDim.length ||
        position.y + itemDim.width > containerDim.width ||
        position.z + itemDim.height > containerDim.height) {
      return false;
    }

    // Check collision with existing items
    for (let space of occupiedSpaces) {
      if (!(position.x >= space.x + space.length ||
            position.x + itemDim.length <= space.x ||
            position.y >= space.y + space.width ||
            position.y + itemDim.width <= space.y ||
            position.z >= space.z + space.height ||
            position.z + itemDim.height <= space.z)) {
        return false;
      }
    }

    return true;
  };

  // Initialize 3D Scene
  useEffect(() => {
    if (!mountRef.current) return;

    // Initialize scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xf8f9fa);
    
    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      75, 
      mountRef.current.clientWidth / mountRef.current.clientHeight, 
      0.1, 
      1000
    );
    camera.position.set(15, 10, 15);
    
    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ 
      antialias: true,
      alpha: true
    });
    renderer.setSize(mountRef.current.clientWidth, mountRef.current.clientHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    
    // Clear previous renderer
    while (mountRef.current.firstChild) {
      mountRef.current.removeChild(mountRef.current.firstChild);
    }
    mountRef.current.appendChild(renderer.domElement);

    // Add orbit controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.25;
    
    // Lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 0.6);
    scene.add(ambientLight);
    
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(10, 10, 5);
    directionalLight.castShadow = true;
    scene.add(directionalLight);

    // Container wireframe
    const containerGeometry = new THREE.BoxGeometry(
      containerSpecs[selectedContainer].length,
      containerSpecs[selectedContainer].width,
      containerSpecs[selectedContainer].height
    );
    const containerMaterial = new THREE.MeshBasicMaterial({
      color: 0x666666,
      wireframe: true,
      transparent: true,
      opacity: 0.3
    });
    const containerMesh = new THREE.Mesh(containerGeometry, containerMaterial);
    containerMesh.position.set(
      containerSpecs[selectedContainer].length / 2,
      containerSpecs[selectedContainer].width / 2,
      containerSpecs[selectedContainer].height / 2
    );
    scene.add(containerMesh);

    // Center camera on container
    camera.lookAt(
      containerSpecs[selectedContainer].length / 2,
      containerSpecs[selectedContainer].width / 2,
      containerSpecs[selectedContainer].height / 2
    );
    controls.target.set(
      containerSpecs[selectedContainer].length / 2,
      containerSpecs[selectedContainer].width / 2,
      containerSpecs[selectedContainer].height / 2
    );

    // Handle window resize
    const handleResize = () => {
      camera.aspect = mountRef.current.clientWidth / mountRef.current.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(mountRef.current.clientWidth, mountRef.current.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    sceneRef.current = scene;
    rendererRef.current = renderer;
    cameraRef.current = camera;
    controlsRef.current = controls;

    // Animation loop
    const animate = () => {
      requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement);
      }
      if (controlsRef.current) {
        controlsRef.current.dispose();
      }
    };
  }, [selectedContainer]);

  // Update 3D visualization when results change
  useEffect(() => {
    if (!results || !sceneRef.current) return;

    // Remove existing item meshes
    const itemsToRemove = [];
    sceneRef.current.traverse((child) => {
      if (child.userData.isItem) {
        itemsToRemove.push(child);
      }
    });
    itemsToRemove.forEach(item => sceneRef.current.remove(item));

    // Add placed items to scene
    results.placedItems.forEach((item, index) => {
      const geometry = new THREE.BoxGeometry(
        item.dimensions.length,
        item.dimensions.width,
        item.dimensions.height
      );
      
      const color = new THREE.Color().setHSL((index * 0.1) % 1, 0.7, 0.6);
      const material = new THREE.MeshLambertMaterial({ 
        color: color,
        transparent: true,
        opacity: 0.8
      });
      
      const mesh = new THREE.Mesh(geometry, material);
      mesh.position.set(
        item.position.x + item.dimensions.length / 2,
        item.position.y + item.dimensions.width / 2,
        item.position.z + item.dimensions.height / 2
      );
      mesh.userData.isItem = true;
      mesh.userData.itemData = item;
      
      sceneRef.current.add(mesh);
    });

    // Reset camera position
    if (cameraRef.current && controlsRef.current) {
      cameraRef.current.position.set(15, 10, 15);
      controlsRef.current.target.set(
        containerSpecs[selectedContainer].length / 2,
        containerSpecs[selectedContainer].width / 2,
        containerSpecs[selectedContainer].height / 2
      );
      controlsRef.current.update();
    }
  }, [results, selectedContainer]);

  const addItem = () => {
    if (!currentItem.name || !currentItem.length || !currentItem.width || !currentItem.height || !currentItem.weight) {
      alert('Please fill all required fields');
      return;
    }

    const newItem = {
      ...currentItem,
      id: Date.now(),
      length: parseFloat(currentItem.length),
      width: parseFloat(currentItem.width),
      height: parseFloat(currentItem.height),
      weight: parseFloat(currentItem.weight),
      quantity: parseInt(currentItem.quantity)
    };

    setItems([...items, newItem]);
    setCurrentItem({
      name: '',
      length: '',
      width: '',
      height: '',
      weight: '',
      quantity: 1,
      stackable: true,
      fragile: false
    });
  };

  const removeItem = (id) => {
    setItems(items.filter(item => item.id !== id));
  };

  const calculateLoad = () => {
    if (items.length === 0) {
      alert('Please add at least one item');
      return;
    }

    const result = binPackingAlgorithm(items, selectedContainer);
    setResults(result);
    setActiveTab('results');
  };

  const exportToPDF = () => {
    const printContent = `
      <h2>Sea Freight Load Calculation Report</h2>
      <h3>Container: ${containerSpecs[selectedContainer].name}</h3>
      <p><strong>Total Items:</strong> ${results.placedItems.length}</p>
      <p><strong>Total Weight:</strong> ${results.totalWeight.toFixed(2)} kg</p>
      <p><strong>Total Volume:</strong> ${results.totalVolume.toFixed(2)} m³</p>
      <p><strong>Space Utilization:</strong> ${results.utilization.toFixed(2)}%</p>
      <p><strong>Weight Utilization:</strong> ${results.weightUtilization.toFixed(2)}%</p>
      
      <h3>Item Details:</h3>
      <table border="1" style="border-collapse: collapse; width: 100%;">
        <tr>
          <th>Item Name</th>
          <th>Dimensions (L×W×H)</th>
          <th>Weight</th>
          <th>Position</th>
        </tr>
        ${results.placedItems.map(item => `
          <tr>
            <td>${item.name}</td>
            <td>${item.length}×${item.width}×${item.height} cm</td>
            <td>${item.weight} kg</td>
            <td>X:${(item.position.x * 100).toFixed(1)}, Y:${(item.position.y * 100).toFixed(1)}, Z:${(item.position.z * 100).toFixed(1)} cm</td>
          </tr>
        `).join('')}
      </table>
    `;
    
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <html>
        <head>
          <title>Load Calculation Report</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            table { margin-top: 20px; }
            th, td { padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
          </style>
        </head>
        <body>${printContent}</body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  return (
    <>
      <link 
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" 
        rel="stylesheet" 
      />
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
      
      <div className="min-vh-100" style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }}>
        <div className="container py-5">
          {/* Header */}
          <div className="text-center mb-5">
            <div className="d-flex justify-content-center align-items-center mb-3">
              <Container className="text-white me-3" size={48} />
              <h1 className="text-white display-4 fw-bold mb-0">Sea Freight Load Calculator</h1>
            </div>
            <p className="text-light fs-5">Optimize your container loading with 3D visualization</p>
          </div>

          {/* Navigation Tabs */}
          <div className="d-flex justify-content-center mb-5">
            <div className="card shadow-lg">
              <div className="card-body p-2">
                <ul className="nav nav-pills nav-fill mb-0">
                  <li className="nav-item">
                    <button
                      className={`nav-link d-flex align-items-center ${activeTab === 'input' ? 'active' : ''}`}
                      style={{ minWidth: '140px' }}
                      onClick={() => setActiveTab('input')}
                    >
                      <Package className="me-2" size={20} />
                      Add Items
                    </button>
                  </li>
                  <li className="nav-item">
                    <button
                      className={`nav-link d-flex align-items-center ${activeTab === 'results' ? 'active' : ''}`}
                      style={{ minWidth: '140px' }}
                      onClick={() => setActiveTab('results')}
                    >
                      <Calculator className="me-2" size={20} />
                      Results
                    </button>
                  </li>
                  <li className="nav-item">
                    <button
                      className={`nav-link d-flex align-items-center ${activeTab === 'visualization' ? 'active' : ''}`}
                      style={{ minWidth: '140px' }}
                      onClick={() => setActiveTab('visualization')}
                    >
                      <Eye className="me-2" size={20} />
                      3D View
                    </button>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Input Tab */}
          {activeTab === 'input' && (
            <div className="row g-4">
              {/* Item Input Form */}
              <div className="col-lg-6">
                <div className="card shadow-lg h-100">
                  <div className="card-header bg-primary text-white">
                    <h5 className="card-title mb-0">
                      <Package className="me-2" size={20} />
                      Add New Item
                    </h5>
                  </div>
                  <div className="card-body">
                    {/* Container Selection */}
                    <div className="mb-4">
                      <label className="form-label fw-semibold">Container Type</label>
                      <select
                        className="form-select"
                        value={selectedContainer}
                        onChange={(e) => setSelectedContainer(e.target.value)}
                      >
                        {Object.entries(containerSpecs).map(([key, spec]) => (
                          <option key={key} value={key}>{spec.name}</option>
                        ))}
                      </select>
                    </div>

                    <div className="row g-3 mb-3">
                      <div className="col-md-8">
                        <label className="form-label fw-semibold">Item Name *</label>
                        <input
                          type="text"
                          className="form-control"
                          value={currentItem.name}
                          onChange={(e) => setCurrentItem({...currentItem, name: e.target.value})}
                          placeholder="Enter item name"
                        />
                      </div>
                      <div className="col-md-4">
                        <label className="form-label fw-semibold">Quantity *</label>
                        <input
                          type="number"
                          className="form-control"
                          value={currentItem.quantity}
                          onChange={(e) => setCurrentItem({...currentItem, quantity: e.target.value})}
                          min="1"
                        />
                      </div>
                    </div>

                    <div className="row g-3 mb-3">
                      <div className="col-md-4">
                        <label className="form-label fw-semibold">Length (cm) *</label>
                        <input
                          type="number"
                          className="form-control"
                          value={currentItem.length}
                          onChange={(e) => setCurrentItem({...currentItem, length: e.target.value})}
                          placeholder="L"
                        />
                      </div>
                      <div className="col-md-4">
                        <label className="form-label fw-semibold">Width (cm) *</label>
                        <input
                          type="number"
                          className="form-control"
                          value={currentItem.width}
                          onChange={(e) => setCurrentItem({...currentItem, width: e.target.value})}
                          placeholder="W"
                        />
                      </div>
                      <div className="col-md-4">
                        <label className="form-label fw-semibold">Height (cm) *</label>
                        <input
                          type="number"
                          className="form-control"
                          value={currentItem.height}
                          onChange={(e) => setCurrentItem({...currentItem, height: e.target.value})}
                          placeholder="H"
                        />
                      </div>
                    </div>

                    <div className="mb-4">
                      <label className="form-label fw-semibold">Weight (kg) *</label>
                      <input
                        type="number"
                        className="form-control"
                        value={currentItem.weight}
                        onChange={(e) => setCurrentItem({...currentItem, weight: e.target.value})}
                        placeholder="Weight in kg"
                      />
                    </div>

                    <div className="d-flex gap-4 mb-4">
                      <div className="form-check">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          checked={currentItem.stackable}
                          onChange={(e) => setCurrentItem({...currentItem, stackable: e.target.checked})}
                        />
                        <label className="form-check-label">Stackable</label>
                      </div>
                      <div className="form-check">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          checked={currentItem.fragile}
                          onChange={(e) => setCurrentItem({...currentItem, fragile: e.target.checked})}
                        />
                        <label className="form-check-label">Fragile</label>
                      </div>
                    </div>

                    <button
                      onClick={addItem}
                      className="btn btn-primary w-100 d-flex align-items-center justify-content-center"
                    >
                      <Plus className="me-2" size={20} />
                      Add Item
                    </button>
                  </div>
                </div>
              </div>

              {/* Items List */}
              <div className="col-lg-6">
                <div className="card shadow-lg h-100">
                  <div className="card-header bg-success text-white">
                    <h5 className="card-title mb-0">
                      <Container className="me-2" size={20} />
                      Items List
                    </h5>
                  </div>
                  <div className="card-body">
                    {items.length === 0 ? (
                      <div className="text-center py-5 text-muted">
                        <Package size={64} className="mb-3 opacity-50" />
                        <p className="fs-5">No items added yet</p>
                        <p>Start by adding items to calculate the load</p>
                      </div>
                    ) : (
                      <>
                        <div className="mb-4" style={{ maxHeight: '400px', overflowY: 'auto' }}>
                          {items.map((item) => (
                            <div key={item.id} className="card mb-2 border-light">
                              <div className="card-body py-2">
                                <div className="d-flex justify-content-between align-items-center">
                                  <div>
                                    <h6 className="card-title mb-1">{item.name}</h6>
                                    <small className="text-muted">
                                      {item.length}×{item.width}×{item.height} cm, {item.weight} kg
                                      {item.quantity > 1 && <span className="badge bg-secondary ms-1">×{item.quantity}</span>}
                                    </small>
                                  </div>
                                  <button
                                    onClick={() => removeItem(item.id)}
                                    className="btn btn-outline-danger btn-sm"
                                  >
                                    <Trash2 size={16} />
                                  </button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>

                        <button
                          onClick={calculateLoad}
                          className="btn btn-success w-100 d-flex align-items-center justify-content-center"
                        >
                          <Calculator className="me-2" size={20} />
                          Calculate Load
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Results Tab */}
          {activeTab === 'results' && results && (
            <div className="card shadow-lg">
              <div className="card-header bg-info text-white d-flex justify-content-between align-items-center">
                <h5 className="card-title mb-0">
                  <Calculator className="me-2" size={20} />
                  Load Calculation Results
                </h5>
                <button
                  onClick={exportToPDF}
                  className="btn btn-light btn-sm d-flex align-items-center"
                >
                  <Download className="me-2" size={16} />
                  Export PDF
                </button>
              </div>
              <div className="card-body">
                <div className="row g-4 mb-5">
                  <div className="col-md-3">
                    <div className="card bg-primary bg-gradient text-white">
                      <div className="card-body text-center">
                        <h3 className="card-title display-6 fw-bold">{results.placedItems.length}</h3>
                        <p className="card-text">Items Placed</p>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-3">
                    <div className="card bg-success bg-gradient text-white">
                      <div className="card-body text-center">
                        <h3 className="card-title display-6 fw-bold">{results.totalWeight.toFixed(0)}</h3>
                        <p className="card-text">Total Weight (kg)</p>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-3">
                    <div className="card bg-warning bg-gradient text-white">
                      <div className="card-body text-center">
                        <h3 className="card-title display-6 fw-bold">{results.utilization.toFixed(1)}%</h3>
                        <p className="card-text">Space Utilization</p>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-3">
                    <div className="card bg-danger bg-gradient text-white">
                      <div className="card-body text-center">
                        <h3 className="card-title display-6 fw-bold">{results.weightUtilization.toFixed(1)}%</h3>
                        <p className="card-text">Weight Utilization</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="card bg-light mb-4">
                  <div className="card-body">
                    <h6 className="card-title">Container Information</h6>
                    <div className="row">
                      <div className="col-md-6">
                        <p className="mb-1"><strong>Type:</strong> {containerSpecs[selectedContainer].name}</p>
                        <p className="mb-1"><strong>Dimensions:</strong> {containerSpecs[selectedContainer].length}×{containerSpecs[selectedContainer].width}×{containerSpecs[selectedContainer].height} m</p>
                      </div>
                      <div className="col-md-6">
                        <p className="mb-1"><strong>Max Weight:</strong> {containerSpecs[selectedContainer].maxWeight.toLocaleString()} kg</p>
                        <p className="mb-1"><strong>Volume:</strong> {containerSpecs[selectedContainer].volume} m³</p>
                      </div>
                    </div>
                  </div>
                </div>

                {results.placedItems.length < items.reduce((sum, item) => sum + item.quantity, 0) && (
                  <div className="alert alert-warning d-flex align-items-center">
                    <Info className="me-2" size={20} />
                    <div>
                      <strong>Warning:</strong> Not all items could be placed in the selected container. 
                      Consider using a larger container or splitting the shipment.
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 3D Visualization Tab */}
          {activeTab === 'visualization' && (
            <div className="card shadow-lg">
              <div className="card-header bg-secondary text-white">
                <h5 className="card-title mb-0">
                  <Eye className="me-2" size={20} />
                  3D Container Visualization
                </h5>
              </div>
              <div className="card-body text-center">
                <div 
                  ref={mountRef} 
                  className="border rounded mx-auto mb-3"
                  style={{ width: '100%', height: '600px' }}
                />
                <div className="text-muted">
                  <p className="mb-1"><strong>Container:</strong> {containerSpecs[selectedContainer].name}</p>
                  <p className="mb-0">Use mouse to rotate and zoom the view</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default SeaFreightCalculator;