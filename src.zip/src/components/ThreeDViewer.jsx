import React from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';

const BoxItem = ({ position, size }) => (
  <mesh position={position}>
    <boxGeometry args={size} />
    <meshStandardMaterial color="orange" />
  </mesh>
);

const ThreeDViewer = ({ items }) => (
  <div className="viewer">
    <Canvas camera={{ position: [3, 3, 6] }}>
      <ambientLight intensity={0.5} />
      <OrbitControls />
      <group>
        {items.map((item, i) => (
          <BoxItem
            key={i}
            position={[i * 1.2, 0, 0]}
            size={[item.width / 100, item.height / 100, item.length / 100]}
          />
        ))}
      </group>
    </Canvas>
  </div>
);

export default ThreeDViewer;