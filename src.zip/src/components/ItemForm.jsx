import React, { useState } from 'react';

const ItemForm = ({ onAdd }) => {
  const [form, setForm] = useState({ length: '', width: '', height: '', weight: '', quantity: '' });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: Number(e.target.value) });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onAdd(form);
    setForm({ length: '', width: '', height: '', weight: '', quantity: '' });
  };

  return (
    <form onSubmit={handleSubmit} className="form">
      {['length', 'width', 'height', 'weight', 'quantity'].map((field) => (
        <input
          key={field}
          name={field}
          type="number"
          placeholder={field}
          value={form[field]}
          onChange={handleChange}
          required
        />
      ))}
      <button type="submit">Add Item</button>
    </form>
  );
};

export default ItemForm;