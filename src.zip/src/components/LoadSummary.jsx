import React from 'react';

const LoadSummary = ({ totalCBM, totalWeight, container }) => (
  <div className="summary">
    <p><strong>Total CBM:</strong> {totalCBM.toFixed(2)} m³</p>
    <p><strong>Total Weight:</strong> {totalWeight.toFixed(2)} kg</p>
    <p><strong>Suggested Container:</strong> {container}</p>
  </div>
);

export default LoadSummary;