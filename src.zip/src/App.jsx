

// App.jsx
import React, { useState } from 'react';
import ItemForm from './components/ItemForm';
import LoadSummary from './components/LoadSummary';
import ThreeDViewer from './components/ThreeDViewer';
import { calculateCBM } from './utils/calculateCBM';
import { suggestContainer } from './utils/containerFit';

const App = () => {
  const [items, setItems] = useState([]);

  const handleAddItem = (item) => {
    setItems([...items, item]);
  };

  const totalCBM = items.reduce(
    (sum, item) => sum + calculateCBM(item.length, item.width, item.height, item.quantity),
    0
  );
  const totalWeight = items.reduce(
    (sum, item) => sum + item.weight * item.quantity,
    0
  );
  const container = suggestContainer(totalCBM);

  return (
    <div className="container">
      <h1>Sea Freight Load Calculator</h1>
      <ItemForm onAdd={handleAddItem} />
      <LoadSummary totalCBM={totalCBM} totalWeight={totalWeight} container={container} />
      <ThreeDViewer items={items} />
    </div>
  );
};

export default App;